<div class="container">
	<div class="col">
		<h1>Selamat Datang di Klinik 4002</h1>
		<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris venenatis dignissim augue, a faucibus leo. In libero erat, sollicitudin vitae tellus ut, condimentum maximus ante. Sed quis libero vitae ligula suscipit tempor. Pellentesque facilisis justo lectus, a tristique lectus ultricies in. Nullam ultricies neque mauris, euismod interdum lorem sagittis vehicula. Aliquam erat volutpat. Curabitur ultrices purus at ipsum tincidunt, at convallis erat facilisis. Integer eget vulputate ligula. Proin pharetra enim neque, sit amet hendrerit enim posuere a. Sed erat augue, varius vel molestie at, tempus in felis. Sed suscipit interdum elit et aliquet. Quisque vel consectetur lacus, eget vulputate massa. Nam non tempus magna.</p>
	</div>
</div>